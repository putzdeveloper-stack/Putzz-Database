const CONFIG = {
  correctPassword: "PutzzBotzz12"
};
